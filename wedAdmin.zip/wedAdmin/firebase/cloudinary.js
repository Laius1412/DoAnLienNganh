const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: 'daturixq2',
  api_key: '474637684398799',
  api_secret: 'hooVs3679T5rTPylkQB4DIV9rno',
});

module.exports = cloudinary;